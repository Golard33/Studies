#include <iostream>
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/graphviz.hpp>
#include <boost/graph/graph_traits.hpp>
#include <boost/graph/depth_first_search.hpp>
#include <boost/graph/reverse_graph.hpp>
#include <boost/graph/graph_utility.hpp>

#include<bits/stdc++.h>
using namespace std;


typedef  pair<int, int> iPair;


struct Graph
{
    int V, E;
    vector< pair<int, iPair> > edges;

    
    Graph(int V, int E)
    {
        this->V = V;
        this->E = E;
    }

    
    void addEdge(int u, int v, int w)
    {
        edges.push_back({w, {u, v}});
    }

    
    int kruskalMST();
};


struct DisjointSets
{
    int *parent, *rnk;
    int n;

    
    DisjointSets(int n)
    {
      
        this->n = n;
        parent = new int[n+1];
        rnk = new int[n+1];

        for (int i = 0; i <= n; i++)
        {
            rnk[i] = 0;

            parent[i] = i;
        }
    }

  
    int find(int u)
    {
        
        if (u != parent[u])
            parent[u] = find(parent[u]);
        return parent[u];
    }

    void merge(int x, int y)
    {
        x = find(x), y = find(y);

      
        if (rnk[x] > rnk[y])
            parent[y] = x;
        else
            parent[x] = y;

        if (rnk[x] == rnk[y])
            rnk[y]++;
    }
};

 

int Graph::kruskalMST()
{
    int mst_wt = 0; 

    sort(edges.begin(), edges.end());

    DisjointSets ds(V);

    vector< pair<int, iPair> >::iterator it;
    for (it=edges.begin(); it!=edges.end(); it++)
    {
        int u = it->second.first;
        int v = it->second.second;

        int set_u = ds.find(u);
        int set_v = ds.find(v);

    
        if (set_u != set_v)
        {
           
            cout << u << " - " << v << endl;

            mst_wt += it->first;

            ds.merge(set_u, set_v);
        }
    }

    return mst_wt;
}

int main()
{
    
    int V = 34 , E = 59;
    Graph g(V, E);

    //premiere ligne
    g.addEdge(1, 2, 8);
    g.addEdge(1, 3, 13);
    g.addEdge(1, 6, 12);
    g.addEdge(1, 11, 1);
    //deuxieme ligne
    g.addEdge(2, 3, 10);
    g.addEdge(2, 9, 21);
    //troisieme ligne
    g.addEdge(3, 4, 11);
    g.addEdge(3, 7, 13);
    g.addEdge(3, 31, 40);
    // quatrieme ligne
    g.addEdge(4, 5, 4);
    g.addEdge(4, 6, 2);
    g.addEdge(4, 7, 22);
    // cinquieme ligne
    g.addEdge(5, 3, 4);
    //sixieme ligne
    g.addEdge(6, 5, 5);
    //septieme ligne
    g.addEdge(7, 8, 2);
    g.addEdge(7, 9, 8);
    // huitieme ligne
    g.addEdge(8, 13, 1);
    //neuvieme ligne
    g.addEdge(9, 8, 10);
    g.addEdge(9, 10, 9);
    // dixieme ligne
    g.addEdge(10, 11, 1);
    g.addEdge(10, 12, 14);
    g.addEdge(10, 13, 2);
    // ongieme ligne
    g.addEdge(11, 12, 14);
    g.addEdge(11, 13, 23);
    //douzieme ligne
    g.addEdge(12, 13, 7);
    //treizieme ligne
    g.addEdge(13, 7, 12);
    g.addEdge(13, 14, 10);
    //quatorzieme ligne
    g.addEdge(14, 7, 8);
    g.addEdge(14, 15, 18);
    //quinzieme ligne
    g.addEdge(15, 16, 11);
    g.addEdge(15, 17, 9);
    //seizieme ligne
    g.addEdge(16, 22, 9);
    g.addEdge(16, 30, 5);
    g.addEdge(16, 31, 6);
    g.addEdge(16, 32, 13);
    g.addEdge(16, 33, 11);
    g.addEdge(16, 34, 13);
    // dix septieme ligne
    g.addEdge(17, 18, 10);
    // dix huitieme ligne
    g.addEdge(18, 19, 7);
    g.addEdge(18, 23, 7);
    // dix neuvieme ligne
    g.addEdge(19, 20, 6);
    g.addEdge(19, 24, 8);
    // vingtieme ligne
    g.addEdge(20, 21, 9);
    // vingt unieme ligne
    g.addEdge(21, 25, 2);
    // vingt deuxieme ligne
    g.addEdge(22, 20, 10);
    g.addEdge(22, 33, 7);
    // vingt troisieme ligne
    g.addEdge(23, 24, 4);
    g.addEdge(23, 26, 8);
    //vingt quatrieme ligne
    g.addEdge(24, 25, 15);
    g.addEdge(24, 26, 6);
    //vingt cinquieme ligne
    g.addEdge(25, 27, 3);
    g.addEdge(25, 28, 4);
    // vingt sixieme ligne
    g.addEdge(26, 29, 10);
    //vingt septieme ligne
    g.addEdge(27, 28, 2);
    // vingt huitieme ligne
    g.addEdge(28, 29, 7);
    // trentieme ligne
    g.addEdge(30, 31, 2);
    g.addEdge(30, 32, 10);
    // trente unieme ligne
    g.addEdge(31, 34, 8);
    // trente deuxieme ligne
    g.addEdge(32, 33, 1); 

    cout << "les noeuds du graphe sont: \n";
    int mst_wt = g.kruskalMST();

    cout << "\nle cout optimal est: " << mst_wt <<endl;

    return 0;
}
